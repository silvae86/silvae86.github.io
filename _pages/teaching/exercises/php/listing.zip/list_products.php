<?php
	// init database first: sqlite3 -init products.sql products.db
	$dbh = new PDO('sqlite:./sql/products.db');
  $dbh->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
  $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $id = $_GET['id'];

  $stmt = $dbh->prepare('SELECT * from category WHERE id = ?');
  $stmt->execute(array($id));
  $category = $stmt->fetch();

  $stmt = $dbh->prepare('SELECT * from product WHERE cat_id = ?');
  $stmt->execute(array($id));
  $products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Shop</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css"> 
    <link href="https://fonts.googleapis.com/css?family=Libre+Franklin|Merriweather" rel="stylesheet"> 
  </head>
  <body>
    <header>
      <h1><a href="list_categories.php">Shop</a></h1>
      <form>
        <input type="text" placeholder="username" name="username">
        <input type="password" placeholder="password" name="password">
        <input type="submit" value="Login">
        <a href="#">Register</a>
      </form>
    </header>
    <section id="products">
      <h2><a href="list_categories.php">Categories</a> &gt; <?=$category['name']?> Products</h2>
      <section class="list">

      <?php foreach($products as $product) { ?>
        <article>
          <h3><?=$product['name']?></h3>        
          <img src="images/<?=$product['id']?>.png">
          <span class="price">€<?=$product['price']?></span>
        </article>
      <?php } ?>
      </section>
    </section>
    <footer>
      <p>Copyright &copy; André Restivo, 2018</p>
    </footer>
  </body>
</html>