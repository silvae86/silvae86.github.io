<!DOCTYPE html>
<html>
  <head>
    <title>Shop</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css"> 
    <link href="https://fonts.googleapis.com/css?family=Libre+Franklin|Merriweather" rel="stylesheet"> 
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
  </head>
  <body>
    <header>
      <h1><a href="list_categories.php">Shop</a></h1>
      <div class="cart"><i class="fas fa-cart-plus"></i> [<?=cartSize()?>]</div>

      <?php if (isset($_SESSION['username'])) { ?>
        <form class="logout" action="action_logout.php">
          <span><?=$_SESSION['username']?></span>
          <input type="submit" value="Logout">
        </form>
      <?php } else { ?>
        <form class="login" action="action_login.php" method="post">
          <input type="text" placeholder="username" name="username">
          <input type="password" placeholder="password" name="password">
          <input type="submit" value="Login">
          <a href="register.php">Register</a>
        </form>
      <?php } ?>
    </header>