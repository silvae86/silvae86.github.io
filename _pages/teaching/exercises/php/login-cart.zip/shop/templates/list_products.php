<section id="products">
      <h2><a href="list_categories.php">Categories</a> &gt; <?=$category['name']?> Products</h2>
      <section class="list">

        <?php foreach($products as $product) { ?>
          <article>
            <h3><?=$product['name']?></h3>        
            <img src="images/<?=$product['id']?>.png">
            <span class="price">€<?=$product['price']?></span>
            <form action="action_add_to_cart.php" method="post">
              <input type="hidden" name="id" value="<?=$product['id']?>">
              <input type="number" value="1" min="1" name="quantity">
              <button type="submit">
                <i class="fas fa-cart-plus"></i>
              </button>
            </form>
          </article>
        <?php } ?>

      </section>
</section>
