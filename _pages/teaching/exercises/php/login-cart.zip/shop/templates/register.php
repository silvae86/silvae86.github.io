<section id="register">
  <h2>Register</h2>
  <form action="action_register.php" method="post">
    <input type="text" name="username" placeholder="username">
    <input type="password" name="password" placeholder="password">
    <input type="submit" value="Register">
  </form>
</section>