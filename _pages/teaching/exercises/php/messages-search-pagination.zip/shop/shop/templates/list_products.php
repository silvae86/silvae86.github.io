<section id="products">
      <h2><a href="list_categories.php">Categories</a> &gt; <?=$category['name']?> Products</h2>
      <form action="list_products.php" method="get">
        <input type="hidden" name="id" value="<?=$id?>">
        <input type="text" name="name" placeholder="name">
        <input type="text" name="min" placeholder="min price">
        <input type="text" name="max" placeholder="max price">
        <input type="submit" value="Search">
      </form>
      <section class="list">
        <?php foreach($products as $product) { ?>
          <article>
            <h3><?=$product['name']?></h3>        
            <img src="images/<?=$product['id']?>.png">
            <span class="price">€<?=$product['price']?></span>
            <form action="action_add_to_cart.php" method="post">
              <input type="hidden" name="id" value="<?=$product['id']?>">
              <input type="number" value="1" min="1" name="quantity">
              <button type="submit">
                <i class="fas fa-cart-plus"></i>
              </button>
            </form>
          </article>
        <?php } ?>
      </section>
      <div class="pagination">
        <a href="?id=<?=$id?>&page=<?=$page-1?>">&lt;</a>
        <?=$page?> 
        <a href="?id=<?=$id?>&page=<?=$page+1?>">&gt;</a>
      </div>
</section>
