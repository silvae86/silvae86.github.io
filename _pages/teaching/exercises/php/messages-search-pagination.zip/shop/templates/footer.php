    <footer>
      <p>Copyright &copy; André Restivo, 2018</p>
    </footer>
  </body>
</html>