<?php
  require_once('config/init.php');
  require_once('database/order.php');

  if (!isset($_SESSION['username'])) {
    $_SESSION['message'] = 'You must login first!';
    die(header('Location: ' . $_SERVER['HTTP_REFERER']));
  }

  $order_id = insertOrder($_SESSION['username']);  

  foreach ($_SESSION['cart'] as $prod_id => $quantity) {
    insertOrderLine($order_id, $prod_id, $quantity);
  }

  unset($_SESSION['cart']);
  $_SESSION['message'] = 'Products ordered!';
  header('Location: ' . $_SERVER['HTTP_REFERER']);
?>