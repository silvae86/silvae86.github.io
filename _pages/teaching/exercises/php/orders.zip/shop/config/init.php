<?php
  session_start();

  // Change the following values: DATABASE, USERNAME and PASSWORD
  $dbh = new PDO('pgsql:host=dbm.fe.up.pt;port=5432;dbname=DATABASE', 'USERNAME', 'PASSWORD');
  $dbh->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
  $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  function cartSize() {
    if (!isset($_SESSION['cart'])) return 0;
    $count = 0;
    foreach($_SESSION['cart'] as $quantity)
      $count += $quantity;
    return $count;
  }

  if (isset($_SESSION['message'])) {
    $_MESSAGE = $_SESSION['message'];
    unset($_SESSION['message']);  
  }
?>
