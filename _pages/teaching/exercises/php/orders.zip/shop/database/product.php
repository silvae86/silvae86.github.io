<?php

  function getProductsByCategory($id, $page) {
    global $dbh;
    $stmt = $dbh->prepare('SELECT * 
                           FROM product 
                           WHERE cat_id = ?
                           ORDER BY id DESC
                           LIMIT 2 OFFSET ?');
    $stmt->execute(array($id, ($page-1) * 2));
    return $stmt->fetchAll();
  }

  function getProductById($id) {
    global $dbh;
    $stmt = $dbh->prepare('SELECT * 
                           FROM product 
                           WHERE id = ?');
    $stmt->execute(array($id));
    return $stmt->fetch();
  }

  function getProductsBySearch($id, $name, $min, $max) {
    global $dbh;

    $query = 'SELECT * FROM product WHERE cat_id = ?';
    $params = array($id);

    if ($name !== '') {
      $query .= ' AND name ILIKE ?';
      $params[] = '%' . $name . '%';
    }

    if ($min !== '') {
      $query .= ' AND price >= ?';
      $params[] = $min;
    }

    if ($max !== '') {
      $query .= ' AND price <= ?';
      $params[] = $max;
    }

    $stmt = $dbh->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll();
  }

?>