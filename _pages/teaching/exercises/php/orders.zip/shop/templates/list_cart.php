<section id="cart">
  <h2>Shopping Cart</h2>

  <table>
    <?php foreach ($products as $product) { ?>
      <tr>
        <td><img src="images/<?=$product['id']?>.png"></td>
        <td><?=$product['name']?></td>
        <td><?=$product['price']?>€</td>
        <td><?=$product['quantity']?></td>
      </tr>
    <?php } ?>
  </table>

  <form action="action_checkout.php">
    <input type="submit" value="Checkout">
  </form>

</section>