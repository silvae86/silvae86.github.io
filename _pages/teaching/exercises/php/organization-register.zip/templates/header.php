<!DOCTYPE html>
<html>
  <head>
    <title>Shop</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css"> 
    <link href="https://fonts.googleapis.com/css?family=Libre+Franklin|Merriweather" rel="stylesheet"> 
  </head>
  <body>
    <header>
      <h1><a href="list_categories.php">Shop</a></h1>
      <form>
        <input type="text" placeholder="username" name="username">
        <input type="password" placeholder="password" name="password">
        <input type="submit" value="Login">
        <a href="register.php">Register</a>
      </form>
    </header>