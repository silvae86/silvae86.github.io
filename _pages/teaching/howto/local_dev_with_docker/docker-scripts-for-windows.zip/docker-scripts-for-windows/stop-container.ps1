$container_name = "php"

docker rm -f "$container_name"
