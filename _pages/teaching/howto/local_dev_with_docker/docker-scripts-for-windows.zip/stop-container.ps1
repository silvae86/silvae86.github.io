$container_name = php

docker stop "$container_name"
